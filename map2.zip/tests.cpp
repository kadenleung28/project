// APSC 142 Engineering Programming Project Starter Code

// Copyright Sean Kauffman 2026



#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN

#include "doctest.h"



#include <stdio.h>



// make sure not to modify anything in this extern block

extern "C"{

#include "defines.h"

#include "map.h"

#include "character.h"

#include "game.h"

char *map = NULL;

int width, height;

}



/**

* This file is where you should put your tests for your code.

* Your code must have tests that execute at least 85% of the code in

* required functions for you to get full marks for the project.

* Make sure to check out the course videos on automated testing for

* more information about how to write tests.

*/



/* Tests for map.c */

TEST_SUITE_BEGIN("Map tests");



// Tests for load_map

TEST_CASE("A test for load_map") {

    CHECK(0 == 0);

}



TEST_SUITE_END();



/* tests for character.c */

TEST_SUITE_BEGIN("Character tests");



// tests for move_character



TEST_CASE("an invalid direction is given to move character") {

    int y = 1, x = 1;

    CHECK(move_character(&y,&x,'z',PLAYER)==MOVED_INVALID_DIRECTION);

}



TEST_CASE("all boundary coverage") {

    width = 3; height = 3;

    map = (char*)malloc(width*height*sizeof(char));

    for (int i=0; i < 9; i++) map[i] = EMPTY;

    int y, x;

    //top boundary (new_y < 0)

    y = 0; x = 1;

    CHECK(move_character(&y,&x,UP,PLAYER)==MOVED_WALL);



    //bottom boundary

    y = 2; x=1;

    CHECK(move_character(&y,&x,DOWN,PLAYER)==MOVED_WALL);



    //left boundary

    y = 1; x = 0;

    CHECK(move_character(&y,&x,LEFT,PLAYER)==MOVED_WALL);



    //left boundary

    y = 1; x = 2;

    CHECK(move_character(&y,&x,RIGHT,PLAYER)==MOVED_WALL);



    free(map);

}



TEST_CASE("hitting a wall") {

    width = 3; height = 3;

    map = (char*)malloc(width*height*sizeof(char));

    for (int i=0; i < 9; i++) map[i] = EMPTY;



    //wall at (1,2)

    map[5] = WALL;

    int y = 1, x = 1;



    CHECK(move_character(&y,&x,RIGHT,PLAYER)==MOVED_WALL);



    free(map);

}



TEST_CASE("testing move character for good moves and walls") {

    width = 3; height = 3;

    map = (char*)malloc(width*height*sizeof(char));

    //create wall

    map[0] = WALL; map [1] = WALL; map [2] = WALL;

    map [4] = PLAYER;



    int py = 1, px = 1;

    //test moving into wall (upwards)

    CHECK(move_character(&py,&px,UP,PLAYER)==MOVED_WALL);

    CHECK(py==1);



    //test moving down (empty space)

    CHECK(move_character(&py,&px,DOWN,PLAYER)==MOVED_OKAY);

    CHECK(py==2);

    CHECK(map[4]==EMPTY);

    CHECK(map[7]==PLAYER);



    free(map);

}



TEST_CASE("testing move_character at map boundaries") {

    width = 3; height = 3;

    map = (char*)malloc(width*height*sizeof(char));

    for (int i=0; i < 9; i++) map[i] = EMPTY;



    int py = 0, px = 0;

    map[0] = PLAYER;



    //try going out of bounds

    CHECK(move_character(&py,&px,LEFT,PLAYER)==MOVED_WALL);

    CHECK(px==0);



    free(map);

}





// tests for locate_character

TEST_CASE("testing locate_character") {

    //use a 3x3 map

    width = 3; height = 3;

    map = (char*)malloc(width*height*sizeof(char));

    for (int i = 0; i<9; i++) map[i] = EMPTY;





    map [8] = MINOTAUR;

    int tx = -1, ty = -1;



    //success

    CHECK (locate_character(MINOTAUR, &ty, &tx) == FOUND_CHARACTER);

    CHECK(ty == 2);

    CHECK(tx == 2);



    //failure

    CHECK(locate_character(PLAYER, &ty, &tx) == CHARACTER_NOT_FOUND);



    free(map);

}

// tests for charge_minotaur



TEST_CASE("charge into empty space") {

    width = 5; height = 5;

    map = (char*)malloc(width*height);

    for (int i=0; i < 25; i++) map[i] = EMPTY;



    int min_y = 2, min_x = 0;

    map[min_y*width+min_x] = MINOTAUR;



    //charge right 2

    CHECK(charge_minotaur(&min_y, &min_x, 4, 4, RIGHT) == MOVED_OKAY);

    CHECK(min_y == 2);

    CHECK(min_x == 2);

    CHECK(map[2*width+0]==EMPTY);

    CHECK(map[2*width+2]==MINOTAUR);

    free(map);



}



TEST_CASE("charge_minotaur to hit and destroy a wall") {

    width = 5; height = 5;

    map = (char*)malloc(width*height);

    for (int i=0; i < 25; i++) map[i] = EMPTY;



    int min_y = 2, min_x = 2;

    map[min_y*width+min_x] = MINOTAUR;

    //wall to the left

    map[2*width+1] = WALL;



    //charge to the left (should hit wall and destroy it)

    CHECK(charge_minotaur(&min_y, &min_x, 0, 0, LEFT) == MOVED_WALL);

    CHECK(min_y == 2);

    CHECK(min_x == 1);

    CHECK(map[2*width+2]==EMPTY);

    CHECK(map[2*width+1]==MINOTAUR);



    free(map);



}



TEST_CASE("charge_minotaur when catching the player") {

    width = 5; height = 5;

    map = (char*)malloc(width*height);

    for (int i=0; i < 25; i++) map[i] = EMPTY;



    int min_y = 4, min_x = 2;

    map[min_y*width+min_x] = MINOTAUR;

    //if plater is at (2,2) or two spaces up

    int ply_y = 2, ply_x = 2;

    map[ply_y*width+ply_x] = MINOTAUR;



    CHECK(charge_minotaur(&min_y, &min_x, ply_y, ply_x, UP) == CAUGHT_PLAYER);

    CHECK(min_y == 2);

    CHECK(min_x == 2);



    free(map);



}



TEST_CASE("checking all boundary coverage for charge_minotaur") {

    width = 3; height = 3;

    map = (char*)malloc(width*height);



    int min_y, min_x;



    //bottom boundary

    for (int i=0; i < 9; i++) map[i] = EMPTY;

    min_y = 2, min_x = 1;

    CHECK(charge_minotaur(&min_y, &min_x, 0, 0, DOWN) == MOVED_WALL);



    //left boundary

    for (int i=0; i < 9; i++) map[i] = EMPTY;

    min_y = 1, min_x = 0;

    CHECK(charge_minotaur(&min_y, &min_x, 2, 2, LEFT) == MOVED_WALL);



    //right boundary

    for (int i=0; i < 9; i++) map[i] = EMPTY;

    min_y = 1, min_x = 2;

    CHECK(charge_minotaur(&min_y, &min_x, 0, 0, RIGHT) == MOVED_WALL);



    free(map);





}



TEST_CASE("charge_minotaur when it reaches the map boundary") {

    width = 3; height = 3;

    map = (char*)malloc(width*height);

    for (int i=0; i < 9; i++) map[i] = EMPTY;



    int min_y = 0, min_x = 1;

    map[min_y*width+min_x] = MINOTAUR;



    //charging upwards

    CHECK(charge_minotaur(&min_y, &min_x, 2, 2, UP) == MOVED_WALL);

    //coords should not change

    CHECK(min_y == 2);



    free(map);



}



TEST_CASE("charge_minotaur when it receives invalid direction") {

    int min_y = 2, min_x = 2;

    CHECK(charge_minotaur(&min_y, &min_x, 0, 0, 'z') == MOVED_INVALID_DIRECTION);

}







// tests for sees_player

TEST_CASE("sees_player for when players are at the same locations") {

    width = 3; height = 3;

    map = (char*)malloc(width*height);

    for (int i=0; i < 9; i++) map[i] = EMPTY;



    //same spot

    CHECK(sees_player(1,1,1,1) == CAUGHT_PLAYER);

    free(map);

}



TEST_CASE("sees_player for diagonal") {

    width = 3; height = 3;

    map = (char*)malloc(width*height);

    for (int i=0; i < 9; i++) map[i] = EMPTY;



    //diagonal, not in a straight line

    CHECK(sees_player(0,0,2,2) == SEES_NOTHING);

    free(map);

}



TEST_CASE("sees_player for a clear direction in all four directions") {

    width = 5; height = 5;

    map = (char*)malloc(width*height);

    for (int i=0; i < 25; i++) map[i] = EMPTY;



    //test up

    CHECK(sees_player(0,2,4,2) == UP);

    // test down

    CHECK(sees_player(4,2,0,2) == DOWN);

    //test left

    CHECK(sees_player(2,0,2,4) == LEFT);

    //test right

    CHECK(sees_player(2,4,2,0) == RIGHT);



    free(map);

}



TEST_CASE("see_player when there is a wall blocking path") {

    width = 5; height = 5;

    map = (char*)malloc(width*height);

    for (int i=0; i < 25; i++) map[i] = EMPTY;



    //player at (2,4) and minotaur at (2,0)

    //wall placed at (2,2)

    map[2*width+2] = WALL;

    CHECK(sees_player(2,4,2,0) == SEES_NOTHING);

    free(map);

}



TEST_SUITE_END();



/* tests for game.c */

TEST_SUITE_BEGIN("Game tests");



// tests for check_win



    // test for when player is still in the map boundaries

    TEST_CASE("testing check_win when inside boundaries") {

        width = 11; height = 12;

        CHECK(check_win(5,5) == KEEP_GOING);

    }



    //check for when player escapes top or left

    TEST_CASE("testing check_win when escaped out top or left") {

        width = 11; height = 12;

        //check top boundary

        CHECK(check_win(-1,5) == YOU_WIN);

        //check left boundary

        CHECK(check_win(5,-1) == YOU_WIN);

    }



    // check for when player escapes bottom or right

    TEST_CASE("testing check_win when escaped out bottom or right") {

        width = 11; height = 12;

        // check bottom boundary

        CHECK(check_win(12,5) == YOU_WIN);

        //check right boundary

        CHECK(check_win(5,11) == YOU_WIN);

    }



// test for check_loss

    // test for when the plater and minotaur are at the same spot

    TEST_CASE("testing check_loss when player and minotaur are in the same location") {

        //if both player and minotaur have the same coordinates, they lose

        CHECK(check_loss(5,5,5,5) == YOU_LOSE);

    }



    // test when player and minotaur are in different locations

    TEST_CASE("testing check_loss when player and minotaur are in seperate locations") {

        // keep going if at different coordinates

        CHECK(check_loss(5,5,9,8) == KEEP_GOING);

    }



TEST_SUITE_END();