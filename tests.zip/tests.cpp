// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2026

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include <stdio.h>

// make sure not to modify anything in this extern block
extern "C"{
#include "defines.h"
#include "map.h"
#include "character.h"
#include "game.h"
char *map = NULL;
int width, height;
}

/**
 * This file is where you should put your tests for your code.
 * Your code must have tests that execute at least 85% of the code in
 * required functions for you to get full marks for the project.
 * Make sure to check out the course videos on automated testing for
 * more information about how to write tests.
 */

/* Tests for map.c */
TEST_SUITE_BEGIN("Map tests");

// Tests for load_map
TEST_CASE("A test for load_map") {
    CHECK(0 == 0);
}

TEST_SUITE_END();

/* tests for character.c */
TEST_SUITE_BEGIN("Character tests");
TEST_CASE("an invalid direction is given to move character") {

    int y = 1, x = 1;

    CHECK(move_character(&x,&y,'z',PLAYER)==MOVED_INVALID_DIRECTION);

}
TEST_CASE("all boundary coverage") {
    width = 3; height = 3;
    map = (char*)malloc(width*height*sizeof(char));
    for (int i=0; i < 9; i++) map[i] = EMPTY;
    int y, x;
    //top boundary (new_y < 0)
    y = 0; x = 1;
    CHECK(move_character(&x,&y,UP,PLAYER)==MOVED_WALL);
    //bottom boundary
    y = 2; x=1;
    CHECK(move_character(&x,&y,DOWN,PLAYER)==MOVED_WALL);
    //left boundary
    y = 1; x = 0;
    CHECK(move_character(&x,&y,LEFT,PLAYER)==MOVED_WALL);
    //left boundary
    y = 1; x = 2;
    CHECK(move_character(&x,&y,RIGHT,PLAYER)==MOVED_WALL);
    free(map);
}
TEST_CASE("hitting a wall") {
    width = 3; height = 3;
    map = (char*)malloc(width*height*sizeof(char));
    for (int i=0; i < 9; i++) map[i] = EMPTY;
    //wall at (1,2)
    map[5] = WALL;
    int y = 1, x = 1;
    CHECK(move_character(&x,&y,RIGHT,PLAYER)==MOVED_WALL);
    free(map);
}
TEST_CASE("testing move character for good moves and walls") {
    width = 3; height = 3;
    map = (char*)malloc(width*height*sizeof(char));
    //create wall
    map[0] = WALL; map [1] = WALL; map [2] = WALL;
    map [4] = PLAYER;
    int py = 1, px = 1;
    //test moving into wall (upwards)
    CHECK(move_character(&py,&px,UP,PLAYER)==MOVED_WALL);
    CHECK(py==1);
    //test moving down (empty space)
    CHECK(move_character(&py,&px,DOWN,PLAYER)==MOVED_OKAY);
    CHECK(py==2);
    CHECK(map[4]==EMPTY);
    CHECK(map[7]==PLAYER);
    free(map);
}
TEST_CASE("testing move_character at map boundaries") {
    width = 3; height = 3;
    map = (char*)malloc(width*height*sizeof(char));
    for (int i=0; i < 9; i++) map[i] = EMPTY;
    int py = 0, px = 0;
    map[0] = PLAYER;
    //try going out of bounds
    CHECK(move_character(&py,&px,LEFT,PLAYER)==MOVED_WALL);
    CHECK(px==0);
    free(map);
}
// tests for locate_character
TEST_CASE("testing locate_character") {
    //use a 3x3 map
    width = 3; height = 3;
    map = (char*)malloc(width*height*sizeof(char));
    for (int i = 0; i<9; i++) map[i] = EMPTY;
    map [8] = MINOTAUR;
    int tx = -1, ty = -1;
    //success
    CHECK (locate_character(MINOTAUR, &ty, &tx) == FOUND_CHARACTER);
    CHECK(ty == 2);
    CHECK(tx == 2);
    //failure
    CHECK(locate_character(PLAYER, &ty, &tx) == CHARACTER_NOT_FOUND);
    free(map);
}

// tests for charge_minotaur

// tests for sees_player

TEST_SUITE_END();

/* tests for game.c */
TEST_SUITE_BEGIN("Game tests");

// tests for check_win
//defined keepgoing as 0
TEST_CASE("check_win returns YOU_WIN only when player is outside map") {
    // Lab instructions: make sure to set width and height inside the test case.
    width = 11;
    height = 12;
        CHECK(check_win(0, 0) == YOU_WIN);
        CHECK(check_win(height - 1, width - 1) == YOU_WIN);
        CHECK(check_win(2, 3) == KEEP_GOING);
        CHECK(check_win(0, 2) == YOU_WIN);

        CHECK(check_win(-1, 0) == YOU_WIN);
        CHECK(check_win(0, -1) == YOU_WIN);
        CHECK(check_win(height, 0) == YOU_WIN);
        CHECK(check_win(0, width) == YOU_WIN);
        CHECK(check_win(height + 10, width + 10) == YOU_WIN);

}



// test for check_loss
TEST_CASE("check_loss returns YOU_LOSE when player and minotaur share same coord") {
        CHECK(check_loss(0, 0, 0, 0) == YOU_LOSE);
        CHECK(check_loss(2, 3, 2, 3) == YOU_LOSE);
        CHECK(check_loss(-1, 5, -1, 5) == YOU_LOSE);
        CHECK(check_loss(0, 0, 0, 1) == KEEP_GOING);
        CHECK(check_loss(0, 0, 1, 0) == KEEP_GOING);
        CHECK(check_loss(10, -4, 10, -3) == KEEP_GOING);
        CHECK(check_loss(10, -4, 9, -4) == KEEP_GOING);
    }
TEST_SUITE_END();
